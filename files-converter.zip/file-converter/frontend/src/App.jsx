import React, { useState } from 'react'

export default function App(){
  const [file, setFile] = useState(null)
  const [target, setTarget] = useState('pdf')
  const [status, setStatus] = useState('')

  async function handleSubmit(e){
    e.preventDefault()
    if(!file){ setStatus('اختر ملفًا'); return }
    setStatus('جارٍ الرفع...')
    const fd = new FormData()
    fd.append('file', file)
    fd.append('target', target)

    try{
      const res = await fetch('http://localhost:4000/api/convert', { method: 'POST', body: fd })
      if(!res.ok){ const j = await res.json(); setStatus('خطأ: '+(j.error||res.statusText)); return }
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      const ext = target
      a.href = url
      a.download = `converted.${ext}`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
      setStatus('اكتمل التحويل')
    }catch(err){
      console.error(err)
      setStatus('فشل التحويل: '+err.message)
    }
  }

  return (
    <div className="container">
      <h1>محول الصيغ</h1>
      <form onSubmit={handleSubmit} className="card">
        <input type="file" onChange={e=>setFile(e.target.files[0])} />
        <label>التحويل إلى:</label>
        <input value={target} onChange={e=>setTarget(e.target.value)} placeholder="مثال: pdf, png, mp4, mp3" />
        <button type="submit">تحويل</button>
      </form>
      <p className="status">{status}</p>
      <footer>صُمم بواسطة ChatGPT — نسخة جاهزة للنشر</footer>
    </div>
  )
}
