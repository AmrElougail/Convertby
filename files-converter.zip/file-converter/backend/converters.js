const fs = require('fs');
const path = require('path');
const libre = require('libreoffice-convert');
const sharp = require('sharp');
const ffmpeg = require('fluent-ffmpeg');
const { v4: uuidv4 } = require('uuid');

const tmpDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

function toBuffer(filePath) {
  return fs.readFileSync(filePath);
}

async function convertDocument(inputPath, outputExt) {
  const inputBuf = toBuffer(inputPath);
  return new Promise((resolve, reject) => {
    libre.convert(inputBuf, `.${outputExt}`, undefined, (err, done) => {
      if (err) return reject(err);
      const outName = path.join(tmpDir, `${uuidv4()}.${outputExt}`);
      fs.writeFileSync(outName, done);
      resolve(outName);
    });
  });
}

async function convertImage(inputPath, outputExt) {
  const outName = path.join(tmpDir, `${uuidv4()}.${outputExt}`);
  await sharp(inputPath).toFile(outName);
  return outName;
}

function convertMedia(inputPath, outputExt) {
  const outName = path.join(tmpDir, `${uuidv4()}.${outputExt}`);
  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .outputOptions('-y')
      .save(outName)
      .on('end', () => resolve(outName))
      .on('error', (err) => reject(err));
  });
}

module.exports = { convertDocument, convertImage, convertMedia };
