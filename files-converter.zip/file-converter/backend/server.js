const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { convertDocument, convertImage, convertMedia } = require('./converters');
const { v4: uuidv4 } = require('uuid');

const app = express();
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, `${uuidv4()}_${file.originalname}`)
});
const upload = multer({ storage });

app.use(express.json());
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.post('/api/convert', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const targetExt = (req.body.target || '').replace('.', '').toLowerCase();
    const mime = req.file.mimetype;
    const inputPath = req.file.path;

    let outPath;
    if (/word|msword|officedocument/.test(mime) || /\.(docx|doc|odt|txt|rtf)$/i.test(req.file.originalname)) {
      outPath = await convertDocument(inputPath, targetExt || 'pdf');
    } else if (/image/.test(mime) || /\.(png|jpe?g|webp|tiff?)$/i.test(req.file.originalname)) {
      outPath = await convertImage(inputPath, targetExt || 'png');
    } else if (/video|audio/.test(mime) || /\.(mp4|mov|mkv|mp3|wav)$/i.test(req.file.originalname)) {
      outPath = await convertMedia(inputPath, targetExt || 'mp4');
    } else {
      return res.status(400).json({ error: 'Unsupported file type' });
    }

    res.download(outPath, (err) => {
      // cleanup
      try { fs.unlinkSync(inputPath); } catch (e) {}
      try { fs.unlinkSync(outPath); } catch (e) {}
      if (err) console.error(err);
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Conversion failed', details: err.message });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
