# File Converter — مشروع جاهز للرفع

هذا المشروع يحتوي على واجهة أمامية React وخادم Node.js لتحويل الملفات باستخدام LibreOffice وffmpeg وsharp.

## تشغيل محلي

### Backend
```bash
cd backend
npm install
node server.js
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## باستخدام Docker
```bash
cd backend
docker build -t file-converter-backend .
docker run -p 4000:4000 file-converter-backend
```

## ملاحظات
- تأكد من تثبيت libreoffice و ffmpeg على السيرفر.
- قم بإضافة سياسات أمان وحجم ملفات للرفع قبل النشر العام.
